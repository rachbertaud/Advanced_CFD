#ifndef READ_INPUTS_H
#define READ_INPUTS_H

#include <map>
#include <string>

void read_inputs(std::map<std::string, double>& variables);

#endif
